require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('./db');
const { auth, roles, canManageGroup } = require('./middleware');

const app = express();
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));
const uploadDir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
});
const photoUpload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype)) });
app.use('/uploads', express.static(uploadDir));

app.get('/health', (_, res) => res.json({ status: 'ok', service: 'UCZ Fellowship API' }));

app.post('/api/auth/register', async (req, res) => {
  try {
    const { fullName, email, password, phone, studentNumber, yearOfStudy } = req.body;
    if (!fullName || !email || !password || password.length < 8)
      return res.status(400).json({ error: 'Full name, email and password (8+ characters) are required' });
    const hash = await bcrypt.hash(password, 12);
    const r = await query(
      `INSERT INTO users(full_name,email,password_hash,phone,student_number,year_of_study)
       VALUES($1,lower($2),$3,$4,$5,$6)
       RETURNING id,full_name,email,role,account_status`,
      [fullName.trim(), email, hash, phone || null, studentNumber || null, yearOfStudy || null]);
    const user = r.rows[0];
    const main = await query("SELECT id FROM groups WHERE name='Main Fellowship Group'");
    if (main.rows[0]) await query(
      `INSERT INTO group_members(group_id,user_id,status,approved_at)
       VALUES($1,$2,'approved',NOW()) ON CONFLICT DO NOTHING`, [main.rows[0].id, user.id]);
    const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'An account with that email already exists' });
    console.error(e); res.status(500).json({ error: 'Could not create account' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const r = await query('SELECT * FROM users WHERE email=lower($1)', [email || '']);
    const user = r.rows[0];
    if (!user || !(await bcrypt.compare(password || '', user.password_hash)))
      return res.status(401).json({ error: 'Incorrect email or password' });
    if (user.account_status !== 'active') return res.status(403).json({ error: 'Account is not active' });
    const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    delete user.password_hash;
    res.json({ token, user });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Login failed' }); }
});

app.get('/api/me', auth, async (req, res) => {
  const r = await query(`SELECT id,full_name,email,phone,student_number,year_of_study,profile_photo_url,role
    FROM users WHERE id=$1`, [req.user.id]);
  res.json(r.rows[0]);
});
app.post('/api/me/photo', auth, photoUpload.single('photo'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a JPG, PNG or WEBP image (max 5MB)' });
  const url = `/uploads/${req.file.filename}`;
  await query('UPDATE users SET profile_photo_url=$1 WHERE id=$2', [url, req.user.id]);
  res.json({ profilePhotoUrl: url });
});

app.get('/api/groups', auth, async (req, res) => {
  const r = await query(`SELECT g.id,g.name,g.description,g.is_open,
    COALESCE(gm.status,'not_joined') AS membership_status
    FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.user_id=$1
    ORDER BY g.name`, [req.user.id]);
  res.json(r.rows);
});
app.post('/api/groups/:id/request', auth, async (req, res) => {
  try {
    const g = await query('SELECT id,is_open FROM groups WHERE id=$1', [req.params.id]);
    if (!g.rowCount) return res.status(404).json({ error: 'Group not found' });
    const status = g.rows[0].is_open ? 'approved' : 'pending';
    await query(`INSERT INTO group_members(group_id,user_id,status,approved_at)
      VALUES($1,$2,$3,CASE WHEN $3='approved' THEN NOW() ELSE NULL END)
      ON CONFLICT(group_id,user_id) DO UPDATE SET status=EXCLUDED.status,requested_at=NOW()`,
      [req.params.id, req.user.id, status]);
    res.json({ message: status === 'approved' ? 'Joined group' : 'Membership request sent', status });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Could not request membership' }); }
});
app.get('/api/groups/:id/members', auth, canManageGroup, async (req, res) => {
  const r = await query(`SELECT u.id,u.full_name,u.email,gm.status,gm.requested_at
    FROM group_members gm JOIN users u ON u.id=gm.user_id
    WHERE gm.group_id=$1 ORDER BY gm.status,u.full_name`, [req.params.id]);
  res.json(r.rows);
});
app.post('/api/groups/:id/members/:userId/approve', auth, canManageGroup, async (req, res) => {
  const r = await query(`UPDATE group_members SET status='approved',approved_at=NOW()
    WHERE group_id=$1 AND user_id=$2 RETURNING *`, [req.params.id, req.params.userId]);
  if (!r.rowCount) return res.status(404).json({ error: 'Membership request not found' });
  res.json({ message: 'Member approved' });
});
app.delete('/api/groups/:id/members/:userId', auth, canManageGroup, async (req, res) => {
  await query('DELETE FROM group_members WHERE group_id=$1 AND user_id=$2',
    [req.params.id, req.params.userId]);
  res.json({ message: 'Group access removed' });
});

app.get('/api/announcements', auth, async (req, res) => {
  const r = await query(`SELECT a.id,a.title,a.body,a.pinned,a.created_at,u.full_name AS author,
    g.name AS group_name FROM announcements a JOIN users u ON u.id=a.author_id
    LEFT JOIN groups g ON g.id=a.group_id
    WHERE a.group_id IS NULL OR EXISTS(
      SELECT 1 FROM group_members gm WHERE gm.group_id=a.group_id
      AND gm.user_id=$1 AND gm.status='approved')
    ORDER BY a.pinned DESC,a.created_at DESC`, [req.user.id]);
  res.json(r.rows);
});
app.post('/api/announcements', auth, roles('leader','admin'), async (req, res) => {
  const { title, body, groupId, pinned } = req.body;
  if (!title || !body) return res.status(400).json({ error: 'Title and message are required' });
  if (groupId && req.user.role !== 'admin') {
    const check = await query('SELECT 1 FROM group_leaders WHERE group_id=$1 AND user_id=$2', [groupId,req.user.id]);
    if (!check.rowCount) return res.status(403).json({ error: 'You do not lead this group' });
  }
  const r = await query(`INSERT INTO announcements(title,body,author_id,group_id,pinned)
    VALUES($1,$2,$3,$4,$5) RETURNING *`, [title,body,req.user.id,groupId || null,!!pinned]);
  res.status(201).json(r.rows[0]);
});

app.get('/api/events', auth, async (_, res) => {
  const r = await query('SELECT * FROM events ORDER BY starts_at');
  res.json(r.rows);
});
app.post('/api/events', auth, roles('leader','admin'), async (req,res) => {
  const { title,description,venue,startsAt,endsAt } = req.body;
  if (!title || !startsAt) return res.status(400).json({error:'Title and start date are required'});
  const r = await query(`INSERT INTO events(title,description,venue,starts_at,ends_at,created_by)
    VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
    [title,description || null,venue || null,startsAt,endsAt || null,req.user.id]);
  res.status(201).json(r.rows[0]);
});

app.get('/api/gallery', auth, async (_,res) => {
  const r = await query('SELECT * FROM gallery_photos ORDER BY created_at DESC');
  res.json(r.rows);
});
app.post('/api/gallery', auth, roles('leader','admin'), photoUpload.single('photo'), async (req,res) => {
  if (!req.file) return res.status(400).json({error:'Photo required (JPG, PNG or WEBP; max 5MB)'});
  const url = `/uploads/${req.file.filename}`;
  const r = await query(`INSERT INTO gallery_photos(caption,image_url,uploaded_by)
    VALUES($1,$2,$3) RETURNING *`, [req.body.caption || null,url,req.user.id]);
  res.status(201).json(r.rows[0]);
});

app.get('/api/hymns', auth, async (req,res) => {
  const language = req.query.language === 'bem' ? 'bem' : 'en';
  const r = await query('SELECT id,hymn_number,title,language,lyrics FROM hymns WHERE language=$1 ORDER BY hymn_number', [language]);
  res.json(r.rows);
});
app.get('/api/contributions', auth, async (req,res) => {
  const r = await query(`SELECT c.*,
    COALESCE((SELECT SUM(p.amount) FROM contribution_payments p
      WHERE p.contribution_id=c.id AND p.user_id=$1 AND p.status='verified'),0) AS my_verified_total
    FROM contributions c ORDER BY c.created_at DESC`, [req.user.id]);
  res.json(r.rows);
});
app.post('/api/contributions', auth, roles('treasurer','admin'), async (req,res) => {
  const { title,description,amount,dueDate } = req.body;
  if (!title || !(Number(amount)>0)) return res.status(400).json({error:'Title and positive amount are required'});
  const r = await query(`INSERT INTO contributions(title,description,amount,due_date,created_by)
    VALUES($1,$2,$3,$4,$5) RETURNING *`,
    [title,description || null,amount,dueDate || null,req.user.id]);
  res.status(201).json(r.rows[0]);
});
app.post('/api/contributions/:id/record-payment', auth, roles('treasurer','admin'), async (req,res) => {
  const { userId,amount,method,reference,status } = req.body;
  if (!userId || !(Number(amount)>0) || !method || !['verified','pending','rejected'].includes(status))
    return res.status(400).json({error:'Valid member, amount, method and status are required'});
  const r = await query(`INSERT INTO contribution_payments
    (contribution_id,user_id,amount,method,reference,status,recorded_by)
    VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.params.id,userId,amount,method,reference || null,status,req.user.id]);
  res.status(201).json(r.rows[0]);
});

app.use((err,req,res,next) => {
  console.error(err);
  res.status(500).json({error:'Unexpected server error'});
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`UCZ Fellowship API listening on ${port}`));
