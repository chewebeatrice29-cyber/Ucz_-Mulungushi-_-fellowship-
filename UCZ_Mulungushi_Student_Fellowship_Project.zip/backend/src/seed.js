require('dotenv').config();
const { query, pool } = require('./db');
const names = [
  ['Main Fellowship Group','General fellowship community',true],
  ['First Year','First-year students',false],['Second Year','Second-year students',false],
  ['Third Year','Third-year students',false],['Fourth Year','Fourth-year students',false],
  ['Final Year','Final-year students',false],['Media Team','Approved media team members',false],
  ['Praise Team','Approved praise team members',false],['Stewards Group','Approved stewards',false],
  ['Intercessors Group','Approved prayer and intercession team members',false]
];
(async () => {
  for (const [name,description,isOpen] of names)
    await query(`INSERT INTO groups(name,description,is_open) VALUES($1,$2,$3)
      ON CONFLICT(name) DO UPDATE SET description=EXCLUDED.description,is_open=EXCLUDED.is_open`,
      [name,description,isOpen]);
  console.log('UCZ fellowship groups seeded.');
  await pool.end();
})().catch(async e => { console.error(e); await pool.end(); process.exit(1); });
