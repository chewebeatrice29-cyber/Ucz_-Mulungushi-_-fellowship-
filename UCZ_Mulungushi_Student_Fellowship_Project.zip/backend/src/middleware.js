const jwt = require('jsonwebtoken');
const { query } = require('./db');

async function auth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Sign in required' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const result = await query(
      'SELECT id, full_name, email, role, account_status FROM users WHERE id=$1',
      [payload.sub]
    );
    if (!result.rows[0] || result.rows[0].account_status !== 'active')
      return res.status(401).json({ error: 'Account unavailable' });
    req.user = result.rows[0];
    next();
  } catch (e) { return res.status(401).json({ error: 'Invalid or expired token' }); }
}
function roles(...allowed) {
  return (req, res, next) => allowed.includes(req.user.role)
    ? next() : res.status(403).json({ error: 'Insufficient permissions' });
}
async function canManageGroup(req, res, next) {
  if (['admin'].includes(req.user.role)) return next();
  const r = await query('SELECT 1 FROM group_leaders WHERE group_id=$1 AND user_id=$2',
    [req.params.id, req.user.id]);
  if (!r.rowCount) return res.status(403).json({ error: 'Group leader permission required' });
  next();
}
module.exports = { auth, roles, canManageGroup };
