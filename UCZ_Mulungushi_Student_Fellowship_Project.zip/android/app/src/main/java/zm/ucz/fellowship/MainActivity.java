package zm.ucz.fellowship;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private final int purple = Color.rgb(103,58,183);
    private LinearLayout root;
    private ApiService api;
    private SharedPreferences prefs;
    private String token = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        api = ApiClient.get().create(ApiService.class);
        prefs = getSharedPreferences("ucz_session", MODE_PRIVATE);
        token = prefs.getString("token", "");
        if (token.isEmpty()) showWelcome(); else showDashboard();
    }

    private void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24); root.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this); scroll.addView(root);
        setContentView(scroll);
        TextView heading = new TextView(this); heading.setText(title); heading.setTextColor(purple);
        heading.setTextSize(25); heading.setGravity(Gravity.CENTER); heading.setPadding(0,8,0,18);
        heading.setTypeface(null, 1); root.addView(heading);
    }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(35,25,45)); t.setPadding(4,12,4,12); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true);
        root.addView(e); return e;
    }
    private void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        root.addView(b); b.setOnClickListener(v -> action.run());
    }
    private void showWelcome() {
        setup("UCZ MULUNGUSHI STUDENT FELLOWSHIP");
        ImageView logo = new ImageView(this);
        try { logo.setImageResource(zm.ucz.fellowship.R.drawable.ucz_logo); } catch(Exception ignored) {}
        logo.setAdjustViewBounds(true); logo.setMaxHeight(230);
        root.addView(logo, new LinearLayout.LayoutParams(-1,230));
        TextView motto = text("\"All One In Christ\"",18); motto.setGravity(Gravity.CENTER);
        motto.setTextColor(purple); root.addView(motto);
        text("Welcome. Grow in faith, fellowship and service.",16);
        button("Sign in", this::showLogin);
        button("Create an account", this::showRegister);
    }
    private void showLogin() {
        setup("Welcome back");
        EditText email = field("Email address");
        EditText password = field("Password"); password.setInputType(129);
        button("Sign in", () -> {
            Map<String,Object> data = new HashMap<>();
            data.put("email", email.getText().toString().trim());
            data.put("password", password.getText().toString());
            api.login(data).enqueue(new Callback<Map>() {
                public void onResponse(Call<Map> c, Response<Map> r) {
                    if (r.isSuccessful() && r.body()!=null) {
                        token = String.valueOf(r.body().get("token"));
                        prefs.edit().putString("token",token).apply(); showDashboard();
                    } else toast("Sign in failed. Check your details.");
                }
                public void onFailure(Call<Map> c, Throwable t) { toast("Cannot reach server: "+t.getMessage()); }
            });
        });
        button("Create account", this::showRegister);
    }
    private void showRegister() {
        setup("Join the fellowship");
        EditText name=field("Full name"), email=field("Email"), phone=field("Phone number");
        EditText student=field("Student number"), year=field("Year of study (e.g. First Year)");
        EditText password=field("Password (at least 8 characters)"); password.setInputType(129);
        button("Register", () -> {
            Map<String,Object> d=new HashMap<>();
            d.put("fullName",name.getText().toString().trim()); d.put("email",email.getText().toString().trim());
            d.put("phone",phone.getText().toString().trim()); d.put("studentNumber",student.getText().toString().trim());
            d.put("yearOfStudy",year.getText().toString().trim()); d.put("password",password.getText().toString());
            api.register(d).enqueue(new Callback<Map>() {
                public void onResponse(Call<Map> c,Response<Map> r) {
                    if(r.isSuccessful() && r.body()!=null) {
                        token=String.valueOf(r.body().get("token")); prefs.edit().putString("token",token).apply(); showDashboard();
                    } else toast("Registration failed. Check details or email.");
                }
                public void onFailure(Call<Map> c,Throwable t) { toast("Cannot reach server: "+t.getMessage()); }
            });
        });
        button("Back to sign in",this::showLogin);
    }
    private void showDashboard() {
        setup("UCZ Student Fellowship");
        TextView welcome=text("All One In Christ  •  Welcome to your fellowship home",16);
        welcome.setGravity(Gravity.CENTER); root.addView(welcome);
        button("Fellowship announcements", () -> loadList("Announcements", api.announcements("Bearer "+token)));
        button("Groups", () -> loadList("Fellowship groups", api.groups("Bearer "+token)));
        button("Calendar & activities", () -> loadList("Upcoming activities", api.events("Bearer "+token)));
        button("My profile", () -> {
            api.me("Bearer "+token).enqueue(new Callback<Map>() {
                public void onResponse(Call<Map> c,Response<Map> r) {
                    if(r.isSuccessful() && r.body()!=null) {
                        Map m=r.body(); new android.app.AlertDialog.Builder(MainActivity.this)
                          .setTitle("My profile").setMessage("Name: "+m.get("full_name")+
                          "\nEmail: "+m.get("email")+"\nRole: "+m.get("role"))
                          .setPositiveButton("OK",null).show();
                    } else toast("Could not load profile");
                }
                public void onFailure(Call<Map> c,Throwable t) { toast("Server unavailable"); }
            });
        });
        button("Sign out", () -> { prefs.edit().clear().apply(); token=""; showWelcome(); });
        text("More fellowship modules (gallery, hymns, contributions and leadership directory) are provided by the API foundation and will be added to the next Android UI milestone.",13);
    }
    private void loadList(String title, Call<Object> call) {
        setup(title);
        TextView result=text("Loading…",15); root.addView(result);
        call.enqueue(new Callback<Object>() {
            public void onResponse(Call<Object> c,Response<Object> r) {
                if(r.isSuccessful()) result.setText(String.valueOf(r.body()));
                else result.setText("Could not load information. Please try again.");
            }
            public void onFailure(Call<Object> c,Throwable t) { result.setText("Server unavailable: "+t.getMessage()); }
        });
        button("Back to home",this::showDashboard);
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
