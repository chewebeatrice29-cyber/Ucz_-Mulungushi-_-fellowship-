package zm.ucz.fellowship;

import java.util.Map;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Header;

public interface ApiService {
    @POST("api/auth/register") Call<Map> register(@Body Map<String,Object> body);
    @POST("api/auth/login") Call<Map> login(@Body Map<String,Object> body);
    @GET("api/me") Call<Map> me(@Header("Authorization") String token);
    @GET("api/groups") Call<Object> groups(@Header("Authorization") String token);
    @GET("api/announcements") Call<Object> announcements(@Header("Authorization") String token);
    @GET("api/events") Call<Object> events(@Header("Authorization") String token);
}
