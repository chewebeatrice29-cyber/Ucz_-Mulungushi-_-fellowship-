package zm.ucz.fellowship;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    // Emulator: http://10.0.2.2:3000/
    // Physical phone: use your computer's LAN IP, e.g. http://192.168.1.10:3000/
    public static final String BASE_URL = "http://10.0.2.2:3000/";
    private static Retrofit retrofit;
    public static Retrofit get() {
        if (retrofit == null) retrofit = new Retrofit.Builder()
            .baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        return retrofit;
    }
}
