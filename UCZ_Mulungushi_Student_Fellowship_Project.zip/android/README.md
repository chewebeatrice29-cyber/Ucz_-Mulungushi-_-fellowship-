# Android app notes
Open this folder in Android Studio. Set the correct `BASE_URL` in `ApiClient.java`.
The current Android milestone includes splash/welcome branding, registration, login,
dashboard, announcements, groups, calendar API views, profile summary and sign out.
The remaining API-backed screens (gallery, contributions, hymns, leadership and group
leader moderation) are planned next; the backend routes/schema are already scaffolded.
