# UCZ Mulungushi Student Fellowship

A starter full-stack project for the UCZ Mulungushi Student Fellowship.

## Included
- Android app source (Java + XML)
- Node.js + Express REST API
- PostgreSQL schema and seed groups
- JWT authentication and role-based authorization
- Group membership requests, approval and removal
- Leader-only announcements
- Events, gallery metadata, hymns and contribution records
- UCZ logo asset

## Important status
This is a runnable development foundation, not a deployed production service or a signed APK.
The Android app and API must be configured with your server address, built, tested and deployed.
Real mobile-money collection is **not** enabled yet: the API records contribution/payment status,
but a real Airtel Money/MTN/Zamtel gateway requires merchant credentials and provider integration.
Do not mark a payment as paid based only on a client-side button.

## Requirements
- Node.js 20+
- PostgreSQL 15+
- Android Studio with Android SDK
- Android device or emulator

## 1. Start the backend
```bash
cd backend
cp .env.example .env
# Edit .env and set DB credentials and a long JWT_SECRET
npm install
createdb ucz_fellowship
psql -d ucz_fellowship -f schema.sql
npm run seed
npm run dev
```
API health check: `http://localhost:3000/health`

For a physical Android phone, the phone and computer must be on the same Wi-Fi network.
Set `BASE_URL` in `android/app/src/main/java/zm/ucz/fellowship/ApiClient.java`
to `http://YOUR_COMPUTER_LAN_IP:3000/`. Do not use `localhost` on a physical phone.
For Android emulator use `http://10.0.2.2:3000/`.

## 2. Open Android project
Open the `android` folder in Android Studio, allow Gradle sync, then run the `app` configuration.
The starter uses Java, XML layouts and Retrofit.

## 3. First administrator
Register a normal account through the app. Then promote the first verified fellowship administrator
directly in PostgreSQL after confirming their identity:
```sql
UPDATE users SET role = 'admin' WHERE email = 'verified-admin@example.com';
```
Never expose admin promotion in public registration.

## 4. Main API routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`
- `GET /api/groups`
- `POST /api/groups/:id/request`
- `GET /api/groups/:id/members` (leader/admin)
- `POST /api/groups/:id/members/:userId/approve` (leader/admin)
- `DELETE /api/groups/:id/members/:userId` (leader/admin)
- `GET /api/announcements`
- `POST /api/announcements` (leader/admin)
- `GET /api/events`
- `POST /api/events` (leader/admin)
- `GET /api/gallery`
- `POST /api/gallery` (leader/admin/media leader; multipart `photo`)
- `GET /api/hymns?language=en|bem`
- `GET /api/contributions`
- `POST /api/contributions` (treasurer/admin)
- `POST /api/contributions/:id/record-payment` (treasurer/admin; manual verified recording only)

## Security notes before public launch
- Use HTTPS and managed hosting.
- Configure email verification and password reset.
- Add audit logs, rate limiting, backups and privacy/consent notices.
- Configure real payment gateway callbacks and verify signatures server-side.
- Confirm UCZ permission to distribute hymn lyrics and photographs.
- Use private object storage for photographs in production; local uploads are for development.
